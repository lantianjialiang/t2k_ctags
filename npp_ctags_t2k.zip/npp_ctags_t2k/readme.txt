1. put the ctags.d folder into %systemdrive%%homepath%\ctags.d
2. put the NppTags folder into Notepad++'s plugins folder
3. enjoy it

Note:
1. please note the timing of tags.sqlite file generatting. 
   if you start the npp first time, click generate, then tags.sqlite file will generate into current focus file's folder
   if you already click generate after npp start, and click second times, the tags.sqlite file location will remember
   if you need create a new tags.sqlite file for difference fodler, please restart npp

2. if the tags.sqlite folder is not what you want, you can move it manually and regenerate

3. only support 32bit version npp
